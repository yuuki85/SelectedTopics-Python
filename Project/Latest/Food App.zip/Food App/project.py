import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

# Connect to SQLite database
con = sqlite3.connect('gourmet.db')

# Create tables
con.execute("""
CREATE TABLE IF NOT EXISTS customer (
    user_id INTEGER PRIMARY KEY,
    name TEXT,
    username TEXT,
    password TEXT,
    mobilehp TEXT
)
""")

con.execute("""
CREATE TABLE IF NOT EXISTS custorder (
    order_id INTEGER PRIMARY KEY,
    order_date TEXT,
    menu_cat TEXT,
    menu_item TEXT,
    total_item INTEGER,
    total_payment REAL,
    user_id INTEGER
)
""")

def read_menu(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    menu = {}
    category = ''
    for line in lines:
        if line.startswith('#'):
            category = line[1:].strip()
            menu[category] = []
        else:
            item, price = line.split('RM')
            menu[category].append((item.strip(), float(price.strip())))
    return menu

def is_owner(user):
    return user.get('username') == 'owner'

#function to register the customer
def register_customer(name, username, password, mobilehp,window):
    if not name or not username or not password or not mobilehp:
        messagebox.showerror("Error", "All fields must be filled")
        return
    con.execute("""
    INSERT INTO customer (name, username, password, mobilehp)
    VALUES (?, ?, ?, ?)
    """, (name, username, password, mobilehp))
    con.commit()
    messagebox.showinfo("Success", "Registration successful")
    window.destroy()

#function to login the customer
def login_customer(username, password, window):
    if not username or not password:
        messagebox.showerror("Error", "All fields must be filled")
        return
    con.row_factory = sqlite3.Row  # Set the row_factory to sqlite3.Row
    cursor = con.cursor()
    cursor.execute("""
    SELECT * FROM customer WHERE username = ? AND password = ?
    """, (username, password))
    result = cursor.fetchone()
    if result:
        messagebox.showinfo("Success", "Login successfuly")
        window.destroy()
        main_menu(dict(result))  # Convert the Row to a dictionary and show the main menu
    else:
        messagebox.showerror("Error", "Invalid username or password")

#calculate the total payment
def calculate_total_payment(menu_cat, menu_item, total_item):
    total_payment = 0
    menu = read_menu('menu.txt') 
    for item, price in menu[menu_cat]:
        if item == menu_item:
            total_payment = price * int(total_item)
            break
    return total_payment

#calculate the total payment in cart
def calculate_cart_total(cart):
    total = sum(item["total_payment"] for item in cart)
    return round(total, 2)

def delete_from_cart(cart, item):
    for i, cart_item in enumerate(cart):
        if cart_item["menu_item"] == item:
            del cart[i]
            return True
    return False

# Function to create a new order
def create_order(user, menu_cat, menu_item, total_item, cart):
    try:
        total_payment = calculate_total_payment(menu_cat, menu_item, total_item)
        total_payment = round(total_payment, 2)
        cart.append({
            "menu_cat": menu_cat,
            "menu_item": menu_item,
            "total_item": total_item,
            "total_payment": total_payment
        })
        messagebox.showinfo("Success", "Added to cart successfully")
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")

def submit_order(user, cart, window):
    try:
        for item in cart:
            con.execute("""
            INSERT INTO custorder (order_date, menu_cat, menu_item, total_item, total_payment, user_id)
            VALUES (datetime('now'), ?, ?, ?, ?, ?)
            """, (item["menu_cat"], item["menu_item"], item["total_item"], item["total_payment"], user.get('user_id')))
        con.commit()
        messagebox.showinfo("Success", "Order submitted successfully")
        cart.clear()  # Clear the cart after submitting the order
        window.destroy()  
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")

# Function to view orders
def view_orders(user):
    cursor = con.cursor()
    cursor.execute("""
    SELECT * FROM custorder WHERE user_id = ?
    """, (user.get('user_id'),))
    return cursor.fetchall()

# Function to update an order
def update_order(order_id, menu_cat, menu_item, total_item,window):
    try:
        total_payment = calculate_total_payment( menu_cat, menu_item, total_item)
        total_payment = round(total_payment, 2)
        con.execute("""
            UPDATE custorder
            SET menu_cat = ?, menu_item = ?, total_item = ?, total_payment = ?
            WHERE order_id = ?
            """, (menu_cat, menu_item, total_item, total_payment, order_id))
        con.commit()
        messagebox.showinfo("Success", "Updated successfuly")
        window.destroy()  # Destroy the window after successful insert
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
   

# Function to cancel an order
def cancel_order(order_id, window):
    try:
        con.execute("""
        DELETE FROM custorder WHERE order_id = ?
        """, (order_id,))
        con.commit()
        messagebox.showinfo("Success", "Deleted successfuly")
        window.destroy()  # Destroy the window after successful insert
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")

def get_sales_data():
    # Connect to the database
    cursor = con.cursor()

    # Execute a query to get the sales data
    cursor.execute("""
        SELECT menu_item, SUM(total_item), SUM(total_payment)
        FROM custorder
        GROUP BY menu_item
    """)

    # Fetch all the rows
    sales_data = cursor.fetchall()  # Changed from con.fetchall() to cursor.fetchall()

    return sales_data

def print_sales():
    if is_owner(logged_in_user):
        # Get the sales data
        sales_data = get_sales_data()

        # Open the sales.txt file in write mode
        with open('sales.txt', 'w') as f:
            # Write the header
            f.write("Item sales count Total\n")

            # Write the sales data
            for item, count, total in sales_data:
                f.write(f"{item} {count} RM {total}\n")
        messagebox.showinfo("Success", "Sales report generated successfully")

#==============================================FRAMES===========================================================
def register():
    # Create a new window
    register_window = tk.Toplevel()
    register_window.title("Register")

    # Create a frame
    frame = ttk.Frame(register_window, padding="10 20 10 20")
    frame.pack(fill='both', expand=True)

    # Create labels and entry fields
    name_label = ttk.Label(frame, text="Name:")
    name_entry = ttk.Entry(frame)
    username_label = ttk.Label(frame, text="Username:")
    username_entry = ttk.Entry(frame)
    password_label = ttk.Label(frame, text="Password:")
    password_entry = ttk.Entry(frame, show='*')
    mobilehp_label = ttk.Label(frame, text="Mobile number:")
    mobilehp_entry = ttk.Entry(frame)

    # Create register button
    register_button = ttk.Button(frame, text="Register", command=lambda: register_customer(name_entry.get(), username_entry.get(), password_entry.get(), mobilehp_entry.get(), register_window))

    # Arrange widgets in grid
    name_label.grid(row=0, column=0, sticky='w', padx=5, pady=5)
    name_entry.grid(row=0, column=1, padx=5, pady=5)
    username_label.grid(row=1, column=0, sticky='w', padx=5, pady=5)
    username_entry.grid(row=1, column=1, padx=5, pady=5)
    password_label.grid(row=2, column=0, sticky='w', padx=5, pady=5)
    password_entry.grid(row=2, column=1, padx=5, pady=5)
    mobilehp_label.grid(row=3, column=0, sticky='w', padx=5, pady=5)
    mobilehp_entry.grid(row=3, column=1, padx=5, pady=5)
    register_button.grid(row=4, column=0, columnspan=2, padx=5, pady=5)

def login():
    # Create a new window
    login_window = tk.Toplevel()
    login_window.title("Login")

    # Create a frame
    frame = ttk.Frame(login_window, padding="10 20 10 20")
    frame.pack(fill='both', expand=True)

    # Create labels and entry fields
    username_label = ttk.Label(frame, text="Username:")
    username_entry = ttk.Entry(frame)
    password_label = ttk.Label(frame, text="Password:")
    password_entry = ttk.Entry(frame, show='*')

    # Create login button
    login_button = ttk.Button(frame, text="Login", command=lambda: login_customer(username_entry.get(), password_entry.get(), login_window))

    # Arrange widgets in grid
    username_label.grid(row=0, column=0, sticky='w', padx=5, pady=5)
    username_entry.grid(row=0, column=1, padx=5, pady=5)
    password_label.grid(row=1, column=0, sticky='w', padx=5, pady=5)
    password_entry.grid(row=1, column=1, padx=5, pady=5)
    login_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

cart = []
def show_create_order(user, cart):
    order_window = tk.Toplevel()
    order_window.title("Create Order")

    # Create a text widget to display the menu
    menu_text = tk.Text(order_window, width=40, height=10)
    menu_text.pack(padx=5, pady=5)

    # Read the menu from menu.txt
    menu = read_menu('menu.txt')

    # Format the menu and insert it into the text widget
    menu_str = ""
    for category, items in menu.items():
        menu_str += f"{category}:\n"
        for item, price in items:
            menu_str += f"  {item} - RM {price}\n"
    menu_text.insert('1.0', menu_str)

    # Create a form to order
    order_form = ttk.Frame(order_window, padding="10 20 10 20")
    order_form.pack(fill='both', expand=True)

    # Create a label and combobox for the menu category
    menu_cat_label = ttk.Label(order_form, text="Menu Category:")
    menu_cat_label.grid(row=1, column=0, sticky='w', padx=5, pady=5)
    menu_categories = list(menu.keys())
    menu_cat_combobox = ttk.Combobox(order_form, values=menu_categories)
    menu_cat_combobox.grid(row=1, column=1, sticky='w', padx=5, pady=5)

    # Create a label and combobox for the menu item
    menu_item_label = ttk.Label(order_form, text="Menu Item:")
    menu_item_label.grid(row=2, column=0, sticky='w', padx=5, pady=5)
    menu_items = []  # Will be filled based on the selected category

    def update_menu_items(event):
        selected_category = menu_cat_combobox.get()
        if selected_category in menu:
            menu_items = [item[0] for item in menu[selected_category]]
            menu_item_combobox['values'] = menu_items
        else:
            menu_item_combobox.set('')
            menu_item_combobox['values'] = []


    menu_item_combobox = ttk.Combobox(order_form, values=menu_items)
    menu_item_combobox.grid(row=2, column=1, sticky='w', padx=5, pady=5)

    # Bind the update_menu_items function to the category combobox
    menu_cat_combobox.bind("<<ComboboxSelected>>", update_menu_items)

    # Create a label and entry for the total item
    total_item_label = ttk.Label(order_form, text="Total Item:")
    total_item_label.grid(row=3, column=0, sticky='w', padx=5, pady=5)
    total_item_entry = ttk.Entry(order_form)
    total_item_entry.grid(row=3, column=1, sticky='w', padx=5, pady=5)

    # Create a button to add the order to the cart
    add_to_cart_button = ttk.Button(order_form, text="Add to Cart", command=lambda: create_order(user, menu_cat_combobox.get(), menu_item_combobox.get(), total_item_entry.get(), cart))
    add_to_cart_button.grid(row=4, column=0, columnspan=2, sticky='w', padx=5, pady=5)

    # Create a button to view the cart
    view_cart_button = ttk.Button(order_form, text="View Cart", command=lambda: view_cart(cart))
    view_cart_button.grid(row=5, column=0, columnspan=2, sticky='w', padx=5, pady=5)
    
    # Create a button to submit the order from the cart
    submit_order_button = ttk.Button(order_form, text="Submit Order", command=lambda: submit_order(user, cart, order_window))
    submit_order_button.grid(row=6, column=0, columnspan=2, sticky='w', padx=5, pady=5)

def show_view_orders(user):
    # Create a new window
    view_orders_window = tk.Toplevel()
    view_orders_window.title("View Orders")

    # Create a treeview widget
    tree = ttk.Treeview(view_orders_window)
    tree["columns"]=("order_id", "order_date", "menu_cat", "menu_item", "total_item", "total_payment")
    tree.column("#0", width=0, stretch=tk.NO)
    tree.column("order_id", anchor=tk.W, width=100)
    tree.column("order_date", anchor=tk.W, width=130)
    tree.column("menu_cat", anchor=tk.W, width=100)
    tree.column("menu_item", anchor=tk.W, width=100)
    tree.column("total_item", anchor=tk.W, width=100)
    tree.column("total_payment", anchor=tk.W, width=100)

    tree.heading("#0", text="", anchor=tk.W)
    tree.heading("order_id", text="Order ID", anchor=tk.W)
    tree.heading("order_date", text="Order Date", anchor=tk.W)
    tree.heading("menu_cat", text="Menu Category", anchor=tk.W)
    tree.heading("menu_item", text="Menu Item", anchor=tk.W)
    tree.heading("total_item", text="Total Item", anchor=tk.W)
    tree.heading("total_payment", text="Total Payment", anchor=tk.W)

    # Fetch data from the custorder table
    orders = view_orders(user)
    for order in orders:
        tree.insert("", "end", values=tuple(order))

    tree.pack()

def view_cart(cart):
    cart_window = tk.Toplevel()
    cart_window.title("View Cart")

    # Create a treeview widget
    tree = ttk.Treeview(cart_window)
    tree["columns"] = ("menu_cat", "menu_item", "total_item", "total_payment")
    tree.column("#0", width=0, stretch=tk.NO)
    tree.column("menu_cat", anchor=tk.W, width=100)
    tree.column("menu_item", anchor=tk.W, width=100)
    tree.column("total_item", anchor=tk.W, width=100)
    tree.column("total_payment", anchor=tk.W, width=100)

    tree.heading("#0", text="", anchor=tk.W)
    tree.heading("menu_cat", text="Menu Category", anchor=tk.W)
    tree.heading("menu_item", text="Menu Item", anchor=tk.W)
    tree.heading("total_item", text="Total Item", anchor=tk.W)
    tree.heading("total_payment", text="Total Payment", anchor=tk.W)

    # Fetch data from the cart
    for item in cart:
        tree.insert("", "end", values=(item["menu_cat"], item["menu_item"], item["total_item"], item["total_payment"]))

    # Display total amount to pay
    total_label = ttk.Label(cart_window, text=f"Total Amount to Pay: RM {calculate_cart_total(cart)}")
    total_label.pack(pady=10)

    tree.pack()
    # Create a button to remove selected item from the cart
    def remove_from_cart():
        selected_item = tree.selection()
        if selected_item:
            item_index = int(selected_item[0][1:]) - 1
            removed_item = cart.pop(item_index)
            messagebox.showinfo("Item Removed", f"Item '{removed_item['menu_item']}' removed from the cart.")
            # Refresh the cart window after removing an item
            cart_window.destroy()
            view_cart(cart)

    remove_button = ttk.Button(cart_window, text="Remove Item", command=remove_from_cart)
    remove_button.pack(pady=10)

def show_update_order(user):
    update_form = tk.Toplevel()
    update_form.title("Update Order")

    # Create a frame for the treeview and form
    tree_form_frame = ttk.Frame(update_form)
    tree_form_frame.grid(row=0, column=0, columnspan=2)

    # Create a treeview widget
    tree = ttk.Treeview(tree_form_frame)
    tree["columns"]=("order_id", "order_date", "menu_cat", "menu_item", "total_item", "total_payment")
    tree.column("#0", width=0, stretch=tk.NO)
    tree.column("order_id", anchor=tk.W, width=100)
    tree.column("order_date", anchor=tk.W, width=130)
    tree.column("menu_cat", anchor=tk.W, width=100)
    tree.column("menu_item", anchor=tk.W, width=100)
    tree.column("total_item", anchor=tk.W, width=100)
    tree.column("total_payment", anchor=tk.W, width=100)

    tree.heading("#0", text="", anchor=tk.W)
    tree.heading("order_id", text="Order ID", anchor=tk.W)
    tree.heading("order_date", text="Order Date", anchor=tk.W)
    tree.heading("menu_cat", text="Menu Category", anchor=tk.W)
    tree.heading("menu_item", text="Menu Item", anchor=tk.W)
    tree.heading("total_item", text="Total Item", anchor=tk.W)
    tree.heading("total_payment", text="Total Payment", anchor=tk.W)
    tree.grid(row=0, column=0)

    # Fetch data from the custorder table
    orders = view_orders(user)
    for order in orders:
        tree.insert("", "end", values=tuple(order))

    tree.pack()

    # Create a text widget to display the menu
    menu_text = tk.Text(update_form, width=40, height=10)
    menu_text.grid(row=1, column=0)

    # Read the menu from menu.txt
    menu = read_menu('menu.txt')

    # Format the menu and insert it into the text widget
    menu_str = ""
    for category, items in menu.items():
        menu_str += f"{category}:\n"
        for item, price in items:
            menu_str += f"  {item} - RM {price}\n"
    menu_text.insert('1.0', menu_str)

    # Create a form to enter the order details
    form_frame = ttk.Frame(update_form)
    form_frame.grid(row=1, column=1, columnspan=2)

    order_id_label = ttk.Label(form_frame, text="Order ID:")
    order_id_label.grid(row=0, column=0)
    order_id_combobox = ttk.Combobox(form_frame, values=[str(order[0]) for order in orders])
    order_id_combobox.grid(row=1, column=0)

    menu_cat_label = ttk.Label(form_frame, text="Menu Category:")
    menu_cat_label.grid(row=2, column=0)
    menu_cat_combobox = ttk.Combobox(form_frame, values=list(menu.keys()))
    menu_cat_combobox.grid(row=3, column=0)

    menu_item_label = ttk.Label(form_frame, text="Menu Item:")
    menu_item_label.grid(row=4, column=0)
    menu_item_combobox = ttk.Combobox(form_frame, values=[])  # Will be filled based on the selected category
    menu_item_combobox.grid(row=5, column=0)

    total_item_label = ttk.Label(form_frame, text="Total Item:")
    total_item_label.grid(row=6, column=0)
    total_item_entry = ttk.Entry(form_frame)
    total_item_entry.grid(row=7, column=0)

    # Bind the update_menu_items function to the category combobox
    def update_menu_items(event):
        selected_category = menu_cat_combobox.get()
        if selected_category in menu:
            menu_items = [item[0] for item in menu[selected_category]]
            menu_item_combobox['values'] = menu_items
        else:
            menu_item_combobox.set('')
            menu_item_combobox['values'] = []

    menu_cat_combobox.bind("<<ComboboxSelected>>", update_menu_items)

    # Create a submit button
    submit_button = ttk.Button(form_frame, text="Submit", command=lambda: update_order(order_id_combobox.get(), menu_cat_combobox.get(), menu_item_combobox.get(), total_item_entry.get(), update_form))
    submit_button.grid(row=8, column=0, padx=5, pady=5)
    
def show_cancel_order(user):
    # Create a new window
    cancel_order_window = tk.Toplevel()
    cancel_order_window.title("Cancel Order")

    # Create a treeview widget
    tree = ttk.Treeview(cancel_order_window)
    tree["columns"]=("order_id", "order_date", "menu_cat", "menu_item", "total_item", "total_payment")
    tree.column("#0", width=0, stretch=tk.NO)
    tree.column("order_id", anchor=tk.W, width=100)
    tree.column("order_date", anchor=tk.W, width=130)
    tree.column("menu_cat", anchor=tk.W, width=100)
    tree.column("menu_item", anchor=tk.W, width=100)
    tree.column("total_item", anchor=tk.W, width=100)
    tree.column("total_payment", anchor=tk.W, width=100)

    tree.heading("#0", text="", anchor=tk.W)
    tree.heading("order_id", text="Order ID", anchor=tk.W)
    tree.heading("order_date", text="Order Date", anchor=tk.W)
    tree.heading("menu_cat", text="Menu Category", anchor=tk.W)
    tree.heading("menu_item", text="Menu Item", anchor=tk.W)
    tree.heading("total_item", text="Total Item", anchor=tk.W)
    tree.heading("total_payment", text="Total Payment", anchor=tk.W)    
    tree.grid(row=0, column=0, columnspan=2,rowspan=3, padx=5, pady=5) 

    # Fetch data from the custorder table
    orders = view_orders(user)
    for order in orders:
        tree.insert("", "end", values=tuple(order))

    # Create a form to enter the order ID
    order_id_label = ttk.Label(cancel_order_window, text="Order ID:")
    order_id_label.grid(row=0, column=2)  

    order_id_entry = ttk.Entry(cancel_order_window)
    order_id_entry.grid(row=1, column=2)  

    # Create a submit button
    submit_button = ttk.Button(cancel_order_window, text="Submit", command=lambda: cancel_order(order_id_entry.get(),cancel_order_window))
    submit_button.grid(row=2, column=2, padx=5, pady=5)  

def main_menu(user):
    global logged_in_user
    logged_in_user = user  # Store the logged-in user globally

    # Create a new window
    main_menu_window = tk.Toplevel()
    main_menu_window.title("Main Menu")

    # Create a frame
    frame = ttk.Frame(main_menu_window, padding="10 20 10 20")
    frame.pack(fill='both', expand=True)

    # Create a label to display the user's name
    user_label = ttk.Label(frame, text=f"Welcome, {user['name']}!")
    user_label.grid(row=0, column=0, sticky='w', padx=5, pady=5)

    
    
    # Only show the "Print Sales" button for the owner
    if is_owner(user):
        print_sales_button = ttk.Button(frame, text="Print Sales", command=print_sales)
        print_sales_button.grid(row=5, column=0, sticky='w', padx=5, pady=5)
        exit_button = ttk.Button(frame, text="Exit", command=main_menu_window.destroy)
        exit_button.grid(row=6, column=0, sticky='w', padx=5, pady=5)
    else:
        create_order_button = ttk.Button(frame, text="1. Create order", command=lambda: show_create_order(user, cart))
        view_orders_button = ttk.Button(frame, text="2. View orders", command=lambda: show_view_orders(user))
        update_order_button = ttk.Button(frame, text="3. Update order", command=lambda: show_update_order(user))
        cancel_order_button = ttk.Button(frame, text="4. Cancel order", command=lambda: show_cancel_order(user))
        exit_button = ttk.Button(frame, text="Exit", command=main_menu_window.destroy)
# Create buttons for the options
    
    # Arrange widgets in grid
    create_order_button.grid(row=1, column=0, sticky='w', padx=5, pady=5)
    view_orders_button.grid(row=2, column=0, sticky='w', padx=5, pady=5)
    update_order_button.grid(row=3, column=0, sticky='w', padx=5, pady=5)
    cancel_order_button.grid(row=4, column=0, sticky='w', padx=5, pady=5)
    exit_button.grid(row=5, column=0, sticky='w', padx=5, pady=5)
    
    

# Main function to run the system
def main():
    
    # Create the main window
    root = tk.Tk()
    root.title("Menu Options")
    root.configure(bg='white')

    # Create a style
    style = ttk.Style(root)
    style.configure('TButton', font=('Arial', 20), background='blue')

    # Create buttons for the options
    register_button = ttk.Button(root, text="Register", command=register)
    login_button = ttk.Button(root, text="Login", command=login)
    exit_button = ttk.Button(root, text="Exit", command=root.destroy)

    # Pack the buttons onto the window
    register_button.pack(ipadx=10, ipady=10, padx=20, pady=20)
    login_button.pack(ipadx=10, ipady=10, padx=20, pady=20)
    exit_button.pack(ipadx=10, ipady=10, padx=20, pady=20)

    # Start the main loop
    root.mainloop()

main()